Projekt do predmetu Seminár Java (IJA), akademický rok 2014/2015.

Názov aplikácie: Labyrinth

Vypracované tímom číslo 124, členovia tímu:
											Norbert Ďurčanský (xdurca01)
											Ján Jusko (xjusko00)

Spustenie aplikácie z koreňového priečinku príkazom ant compile run.
