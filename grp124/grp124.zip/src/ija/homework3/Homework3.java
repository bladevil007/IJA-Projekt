package ija.homework3;

import ija.homework3.Gui.Gui;
import ija.homework3.ui.ui;
import javax.swing.JFrame;

/**
 * Main class.
 * Name stayed from the third assignment. We are sorry it is misleading.
 * @author Norbert Durcansky (xdurca01)<br>
 *         Jan Jusko (xjusko00)
 */
public class Homework3 {
    

    /**
     * Function Main of whole project.
     * Starts the Gui main class.
     * woooo!
     * @param args the command line arguments
     */
     public static void main(String[] args) {

         // Gamegui gameg=new Gamegui();
        //  gameg.create();  
      // Master universe=Master.create();
        Gui.main(args);
        //ui textUI = new ui(universe);
      // textUI.start();
    
    }
   
    
}
